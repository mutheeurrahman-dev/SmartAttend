# SmartAttend: LAN-Based Classroom Attendance System

ESP32 creates its own Wi-Fi network. Students join it, open a web page and mark attendance.
The teacher watches a live dashboard and downloads a CSV. No internet, no router.

## Folder contents

| Path | What it is |
|---|---|
| `SmartAttend/SmartAttend.ino` | Complete ESP32 firmware. Open this in Arduino IDE. |
| `docs/SmartAttend_Block_Connection_Diagram.png` | Connection diagram with pin tables |
| `docs/SmartAttend_Wiring_Diagram.png` | Simple wiring diagram with D-pin labels |
| `docs/admin_preview.html` | Teacher dashboard with simulated data. Double-click to view in a browser. |
| `docs/student_preview.html` | Student page preview with simulated data |
| `web/student.html`, `web/admin.html` | Readable source of the two pages embedded in the firmware |

## Hardware

ESP32 DevKit, 0.96" I2C OLED (SSD1306), KY-023 joystick, green LED, red LED, 2 x 220 ohm resistors,
active buzzer, breadboard, jumper wires, USB cable.

## Wiring

| ESP32 pin | Connects to |
|---|---|
| D21 | OLED SDA |
| D22 | OLED SCL |
| D25 | Green LED anode through 220 ohm (cathode to GND) |
| D26 | Red LED anode through 220 ohm (cathode to GND) |
| D27 | Active buzzer + (minus to GND) |
| D34 | Joystick VRx |
| D35 | Joystick VRy |
| D33 | Joystick SW |
| 3V3 | OLED VCC and Joystick VCC (**3.3V, never 5V**) |
| GND | All grounds |

## Upload steps

1. Install the ESP32 board package in Arduino IDE.
2. Library Manager: install **Adafruit GFX Library** and **Adafruit SSD1306**.
3. Open `SmartAttend/SmartAttend.ino`. The folder name must stay `SmartAttend`.
4. Tools > Board > **ESP32 Dev Module**, choose the COM port, click Upload.

Settings at the top of the sketch:

- `USE_SH1106` set to `1` if your OLED is a 1.3" SH1106 (also install **Adafruit SH110X**).
- `JOY_INVERT_Y` set to `1` if joystick up and down feel reversed.
- `ADMIN_PIN` is the teacher PIN. **Change it from 1234 before your demo.**
- `WIFI_SSID` and `WIFI_PASS` (password needs at least 8 characters).

## How to use

1. Power the ESP32. The OLED shows the menu. The red LED means the session is closed.
2. Joystick up/down moves the menu, pressing the stick selects. **Start attendance** turns the green LED on.
3. Students join Wi-Fi `SmartAttend` (password `12345678`). The attendance page opens automatically on most phones, otherwise go to `http://192.168.4.1`.
4. Teacher opens `http://192.168.4.1/admin`, enters the PIN, and sees students appear live.
5. Stop the session with the joystick or the dashboard, then press **Download CSV**.

Feedback: green flash and one beep = attendance saved. Two red flashes and two beeps = rejected
(closed, duplicate device, or duplicate register number).

## Networking concepts demonstrated

Wi-Fi access point mode, DHCP, IPv4 addressing (192.168.4.0/24), DNS redirect (captive portal),
HTTP client-server (GET and POST), REST-style JSON endpoints, polling, multiple clients.

| Endpoint | Purpose | Needs PIN |
|---|---|---|
| `/` | Student page | no |
| `/status` | Session open or closed | no |
| `/submit` (POST) | Mark attendance | no |
| `/admin` | Dashboard page | login inside page |
| `/data`, `/toggle`, `/clear`, `/csv` | Dashboard API | yes |

## Duplicate protection

A submission is rejected if the device IP, a browser-generated device ID, or the register number was already
used in the session. This is strong enough for a classroom demo, but it is not tamper-proof: a student who
clears browser data, changes the IP and types someone else's register number could still get through.

## Known limits

- The ESP32 access point supports **10 phones connected at the same time**. Students can disconnect after
  submitting so others can join. Up to 60 records are stored.
- Attendance is kept in RAM and is lost if the ESP32 restarts. Download the CSV before powering off.
- Time is measured from the start of the session (the ESP32 has no real clock).
- Traffic is plain HTTP on a WPA2 network. Fine for a demo, not for sensitive data.

## Troubleshooting

| Problem | Fix |
|---|---|
| OLED blank | Check SDA and SCL. Try `USE_SH1106 1`. Address is 0x3C. |
| Joystick reversed | Set `JOY_INVERT_Y 1` |
| Phone says "no internet" | Normal. Stay connected and open `http://192.168.4.1` |
| Page does not open | Turn off mobile data on the phone |
| Buzzer silent | It must be an **active** buzzer. Check polarity. |
