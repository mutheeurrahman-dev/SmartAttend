/*
  ============================================================
  SmartAttend - LAN Based Classroom Attendance System
  ESP32 + I2C OLED + KY-023 Joystick + Green/Red LED + Buzzer
  ============================================================
  Board    : ESP32 Dev Module (Arduino-ESP32 core 2.x or 3.x)
  Libraries: Adafruit GFX Library, Adafruit SSD1306
             (Adafruit SH110X only if USE_SH1106 is set to 1)

  Pins (ESP32 D-labels = GPIO numbers)
    OLED SDA D21 | OLED SCL D22 | OLED VCC 3V3 | OLED GND GND
    Green LED D25 (220 ohm) | Red LED D26 (220 ohm)
    Active buzzer + D27, - GND
    Joystick VRx D34 | VRy D35 | SW D33 | VCC 3V3 | GND GND

  Usage
    1. Power the ESP32, join Wi-Fi "SmartAttend" (password below).
    2. Students open http://192.168.4.1 (the page also pops up
       automatically on most phones, like a hotspot login page).
    3. Teacher opens http://192.168.4.1/admin and enters ADMIN_PIN.
    4. Start / stop the session with the joystick or the dashboard.
  ============================================================
*/

#include <WiFi.h>
#include <WebServer.h>
#include <DNSServer.h>
#include <Wire.h>
#include <Adafruit_GFX.h>

// ---------------- USER SETTINGS ----------------
#define USE_SH1106    1        // 0 = 0.96" SSD1306, 1 = 1.3" SH1106
#define JOY_INVERT_Y  0        // set to 1 if UP/DOWN feel reversed
const char* WIFI_SSID = "SmartAttend";
const char* WIFI_PASS = "12345678";   // minimum 8 characters
const char* ADMIN_PIN = "1234";       // CHANGE THIS before your demo
#define MAX_STUDENTS  60

// ---------------- OLED ----------------
#if USE_SH1106
  #include <Adafruit_SH110X.h>
  Adafruit_SH1106G display(128, 64, &Wire, -1);
  #define OLED_ON SH110X_WHITE
#else
  #include <Adafruit_SSD1306.h>
  Adafruit_SSD1306 display(128, 64, &Wire, -1);
  #define OLED_ON SSD1306_WHITE
#endif

// ---------------- PINS ----------------
#define OLED_SDA  21
#define OLED_SCL  22
#define GREEN_LED 25
#define RED_LED   26
#define BUZZER    27
#define JOY_X     34
#define JOY_Y     35
#define JOY_SW    33

// ---------------- NETWORK ----------------
const IPAddress AP_IP(192, 168, 4, 1);
WebServer server(80);
DNSServer dnsServer;

// ---------------- WEB PAGES (generated from /web/*.html) ----------------
const char STUDENT_HTML[] PROGMEM = R"HTMLPAGE(<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>SmartAttend</title>
<style>
:root{--brand:#4f46e5;--brand2:#06b6d4;--ink:#1e1b4b;--mut:#6b7280;--ok:#059669;--err:#dc2626}
*{box-sizing:border-box;margin:0;padding:0;font-family:system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif}
body{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;
  background:linear-gradient(135deg,var(--brand),var(--brand2))}
.card{background:#fff;width:100%;max-width:400px;border-radius:24px;padding:30px 24px 24px;
  box-shadow:0 24px 60px rgba(15,23,42,.35)}
.logo{width:56px;height:56px;border-radius:16px;margin:0 auto 12px;display:grid;place-items:center;
  color:#fff;font-weight:800;font-size:20px;background:linear-gradient(135deg,var(--brand),var(--brand2))}
h1{font-size:22px;color:var(--ink);text-align:center}
.sub{text-align:center;color:var(--mut);font-size:13px;margin:4px 0 16px}
.pill{display:flex;align-items:center;gap:8px;width:fit-content;margin:0 auto 20px;padding:7px 16px;
  border-radius:999px;font-size:12px;font-weight:700;letter-spacing:.5px}
.pill i{width:8px;height:8px;border-radius:50%;background:currentColor}
.pill.on{background:#d1fae5;color:#047857}.pill.on i{animation:pulse 1.4s infinite}
.pill.off{background:#fee2e2;color:#b91c1c}.pill.wait{background:#e5e7eb;color:#4b5563}
@keyframes pulse{0%{box-shadow:0 0 0 0 rgba(4,120,87,.6)}100%{box-shadow:0 0 0 8px rgba(4,120,87,0)}}
label{display:block;font-size:12px;font-weight:700;color:#4b5563;margin:0 0 6px}
input{width:100%;padding:13px 14px;margin-bottom:16px;border:1.5px solid #e5e7eb;border-radius:12px;
  font-size:16px;outline:none;transition:border .2s,box-shadow .2s}
input:focus{border-color:var(--brand);box-shadow:0 0 0 4px rgba(79,70,229,.12)}
button{width:100%;padding:15px;border:0;border-radius:12px;color:#fff;font-size:15px;font-weight:800;
  letter-spacing:.5px;cursor:pointer;background:linear-gradient(135deg,var(--brand),var(--brand2));transition:transform .1s,opacity .2s}
button:active{transform:scale(.98)}button:disabled{opacity:.55;cursor:not-allowed}
#msg{margin-top:16px;text-align:center;font-size:13px;font-weight:700;min-height:18px}
.ok{color:var(--ok)}.err{color:var(--err)}
.done{text-align:center;padding:10px 0}
.tick{width:72px;height:72px;border-radius:50%;background:#d1fae5;color:var(--ok);display:grid;place-items:center;
  font-size:38px;margin:0 auto 14px;animation:pop .35s ease}
@keyframes pop{0%{transform:scale(.4);opacity:0}100%{transform:scale(1);opacity:1}}
.foot{margin-top:18px;text-align:center;font-size:11px;color:#9ca3af}
.hide{display:none}
</style>
</head>
<body>
<div class="card">
  <div class="logo">SA</div>
  <h1>SmartAttend</h1>
  <div class="sub">Classroom attendance over local Wi-Fi</div>
  <div id="pill" class="pill wait"><i></i><span id="pillTxt">CHECKING</span></div>

  <div id="formBox">
    <label for="name">Full name</label>
    <input id="name" type="text" maxlength="40" placeholder="e.g. Nithish" autocomplete="name">
    <label for="regno">Register number</label>
    <input id="regno" type="text" maxlength="20" placeholder="e.g. 21CS045" autocapitalize="characters" autocomplete="off">
    <button id="btn">MARK ATTENDANCE</button>
    <div id="msg"></div>
  </div>

  <div id="doneBox" class="done hide">
    <div class="tick">&#10003;</div>
    <h1>You are marked present</h1>
    <div class="sub" id="doneName"></div>
  </div>

  <div class="foot">One submission per device per session</div>
</div>

<script>
const $ = id => document.getElementById(id);
function ls(k, v) {
  try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) {}
  return null;
}
let did = ls('sa_did');
if (!did) { did = Math.random().toString(36).slice(2) + Date.now().toString(36); ls('sa_did', did); }
let active = false, sid = '', sending = false;

function setPill(cls, txt) { $('pill').className = 'pill ' + cls; $('pillTxt').textContent = txt; }
function showDone(name) {
  $('formBox').classList.add('hide');
  $('doneBox').classList.remove('hide');
  $('doneName').textContent = name || '';
}
function refreshButton() { $('btn').disabled = sending || !active; }

async function poll() {
  try {
    const r = await fetch('/status', { cache: 'no-store' });
    const d = await r.json();
    active = d.active; sid = String(d.sid);
    setPill(active ? 'on' : 'off', active ? 'ATTENDANCE OPEN' : 'ATTENDANCE CLOSED');
    if (ls('sa_done_sid') === sid) showDone(ls('sa_done_name'));
  } catch (e) { setPill('wait', 'NOT CONNECTED'); }
  refreshButton();
}

async function submit() {
  const name = $('name').value.trim(), regno = $('regno').value.trim();
  const msg = $('msg');
  if (name.length < 2 || regno.length < 2) { msg.textContent = 'Enter your name and register number'; msg.className = 'err'; return; }
  sending = true; refreshButton(); $('btn').textContent = 'SUBMITTING...';
  try {
    const r = await fetch('/submit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ name: name, regno: regno, did: did })
    });
    const t = await r.text();
    const i = t.indexOf('|');
    const kind = i < 0 ? 'ERR' : t.slice(0, i), text = i < 0 ? t : t.slice(i + 1);
    if (kind === 'OK') {
      ls('sa_done_sid', sid); ls('sa_done_name', name + ' (' + regno.toUpperCase() + ')');
      showDone(name + ' (' + regno.toUpperCase() + ')');
    } else { msg.textContent = text; msg.className = 'err'; }
  } catch (e) { msg.textContent = 'Connection error. Try again.'; msg.className = 'err'; }
  sending = false; $('btn').textContent = 'MARK ATTENDANCE'; refreshButton();
}

$('btn').addEventListener('click', submit);
poll(); setInterval(poll, 3000);
</script>
</body>
</html>
)HTMLPAGE";

const char ADMIN_HTML[] PROGMEM = R"HTMLPAGE(<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>SmartAttend Dashboard</title>
<style>
:root{--brand:#4f46e5;--brand2:#06b6d4;--ink:#1e1b4b;--mut:#6b7280;--bg:#f3f4fb;--card:#fff;--ok:#059669;--err:#dc2626}
*{box-sizing:border-box;margin:0;padding:0;font-family:system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif}
body{background:var(--bg);color:var(--ink);min-height:100vh}
.wrap{max-width:1000px;margin:0 auto;padding:22px 16px 60px}
header{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;margin-bottom:22px}
.brand{display:flex;align-items:center;gap:12px}
.logo{width:46px;height:46px;border-radius:14px;display:grid;place-items:center;color:#fff;font-weight:800;
  background:linear-gradient(135deg,var(--brand),var(--brand2))}
h1{font-size:21px}.brand span{font-size:12px;color:var(--mut)}
.pill{display:flex;align-items:center;gap:8px;padding:8px 16px;border-radius:999px;font-size:12px;font-weight:800;letter-spacing:.5px}
.pill i{width:9px;height:9px;border-radius:50%;background:currentColor}
.pill.on{background:#d1fae5;color:#047857}.pill.on i{animation:pulse 1.4s infinite}
.pill.closed{background:#fee2e2;color:#b91c1c}.pill.off{background:#e5e7eb;color:#4b5563}
@keyframes pulse{0%{box-shadow:0 0 0 0 rgba(4,120,87,.6)}100%{box-shadow:0 0 0 9px rgba(4,120,87,0)}}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:14px;margin-bottom:16px}
.stat{background:var(--card);border-radius:18px;padding:18px;box-shadow:0 8px 24px rgba(30,27,75,.07)}
.stat.main{display:flex;align-items:center;gap:16px}
.lbl{font-size:11px;font-weight:800;color:var(--mut);letter-spacing:.6px;text-transform:uppercase}
.big{font-size:32px;font-weight:800;color:var(--brand);margin-top:4px}
.big.sm{font-size:20px;margin-top:8px}
.sub{font-size:12px;color:var(--mut);margin-top:4px}
.ring{--deg:0deg;width:76px;height:76px;flex:none;border-radius:50%;position:relative;display:grid;place-items:center;
  background:conic-gradient(var(--brand) var(--deg),#e5e7eb 0);transition:background .4s}
.ring::after{content:"";position:absolute;inset:10px;background:#fff;border-radius:50%}
.ring span{position:relative;z-index:1;font-weight:800;font-size:14px}
.stat input{width:100%;margin-top:8px;padding:9px 12px;border:1.5px solid #e5e7eb;border-radius:10px;font-size:15px;outline:none}
.stat input:focus{border-color:var(--brand)}
.controls{background:var(--card);border-radius:18px;padding:14px;box-shadow:0 8px 24px rgba(30,27,75,.07);
  display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin-bottom:16px}
.controls .search{flex:1;min-width:180px;padding:11px 14px;border:1.5px solid #e5e7eb;border-radius:12px;font-size:14px;outline:none}
.controls .search:focus{border-color:var(--brand)}
.btn{padding:11px 18px;border:0;border-radius:12px;font-size:13px;font-weight:800;color:#fff;cursor:pointer;letter-spacing:.3px}
.btn:active{transform:scale(.97)}
.b-start{background:var(--ok)}.b-stop{background:var(--err)}.b-csv{background:var(--brand)}.b-clear{background:#64748b}
.tablebox{background:var(--card);border-radius:18px;box-shadow:0 8px 24px rgba(30,27,75,.07);overflow:hidden}
.scroll{overflow-x:auto}
table{width:100%;border-collapse:collapse;min-width:520px}
th,td{text-align:left;padding:13px 16px;font-size:13px}
th{background:#f5f5fd;color:#4b5563;font-size:11px;font-weight:800;letter-spacing:.6px;text-transform:uppercase}
tbody tr{border-top:1px solid #f0f0f8}
tbody tr.new{animation:flash 2.4s ease}
@keyframes flash{0%{background:#d1fae5}100%{background:transparent}}
.who{display:flex;align-items:center;gap:10px;font-weight:700}
.av{width:32px;height:32px;border-radius:50%;display:grid;place-items:center;color:#fff;font-size:12px;font-weight:800;
  background:linear-gradient(135deg,var(--brand),var(--brand2))}
.mono{font-family:ui-monospace,Menlo,Consolas,monospace;color:var(--mut)}
.empty{text-align:center;padding:40px 10px;color:#9ca3af;font-size:14px}
#toast{position:fixed;left:50%;bottom:24px;transform:translateX(-50%) translateY(90px);background:#111827;color:#fff;
  padding:12px 20px;border-radius:12px;font-size:13px;font-weight:600;transition:transform .3s;z-index:20;max-width:90vw}
#toast.show{transform:translateX(-50%) translateY(0)}
.modal{position:fixed;inset:0;background:rgba(15,23,42,.6);display:none;place-items:center;z-index:30;padding:20px}
.modal.show{display:grid}
.box{background:#fff;border-radius:20px;padding:26px;width:100%;max-width:340px;text-align:center}
.box h2{font-size:19px;margin-bottom:6px}.box p{font-size:13px;color:var(--mut);margin-bottom:16px}
.box input{width:100%;padding:13px;border:1.5px solid #e5e7eb;border-radius:12px;font-size:20px;text-align:center;letter-spacing:6px;outline:none;margin-bottom:12px}
.box .btn{width:100%;background:var(--brand)}
#pinErr{color:var(--err);font-size:12px;font-weight:700;margin-top:10px;min-height:16px}
</style>
</head>
<body>
<div class="modal" id="pinModal">
  <div class="box">
    <h2>Teacher login</h2>
    <p>Enter the admin PIN to open the dashboard</p>
    <input id="pinInput" type="password" inputmode="numeric" maxlength="12" autocomplete="off">
    <button class="btn" id="pinBtn">UNLOCK</button>
    <div id="pinErr"></div>
  </div>
</div>

<div class="wrap">
  <header>
    <div class="brand"><div class="logo">SA</div><div><h1>SmartAttend</h1><span>Teacher dashboard</span></div></div>
    <div id="pill" class="pill off"><i></i><b id="pillTxt">CONNECTING</b></div>
  </header>

  <section class="stats">
    <div class="stat main">
      <div class="ring" id="ring"><span id="ringTxt">0</span></div>
      <div><div class="lbl">Present</div><div class="big" id="count">0</div><div class="sub" id="pct">Set class strength for %</div></div>
    </div>
    <div class="stat"><div class="lbl">Session time</div><div class="big" id="timer">00:00</div><div class="sub" id="stateTxt">Closed</div></div>
    <div class="stat"><div class="lbl">Class strength</div><input id="classSize" type="number" min="0" max="500" placeholder="e.g. 60"></div>
    <div class="stat"><div class="lbl">Students join at</div><div class="big sm" id="ip">192.168.4.1</div><div class="sub" id="ssid">Wi-Fi: SmartAttend</div></div>
  </section>

  <section class="controls">
    <input class="search" id="search" type="search" placeholder="Search name or register number">
    <button class="btn b-start" id="bStart">START</button>
    <button class="btn b-stop" id="bStop">STOP</button>
    <button class="btn b-csv" id="bCsv">DOWNLOAD CSV</button>
    <button class="btn b-clear" id="bClear">CLEAR</button>
  </section>

  <section class="tablebox"><div class="scroll">
    <table>
      <thead><tr><th>#</th><th>Student</th><th>Register no.</th><th>Time</th><th>Device IP</th></tr></thead>
      <tbody id="rows"></tbody>
    </table>
  </div></section>
</div>
<div id="toast"></div>

<script>
const $ = id => document.getElementById(id);
const esc = s => String(s).replace(/[&<>"']/g, c => ({
  '&': '&amp;',
  '<': '&lt;',
  '>': '&gt;',
  '"': '&quot;',
  "'": '&#39;'
}[c]));
let pin = '';
try { pin = sessionStorage.getItem('sa_pin') || ''; } catch (e) {}
let data = { active:false, count:0, students:[], ip:'192.168.4.1', ssid:'SmartAttend', sec:0 };
let known = null, toastTimer = null;

function toast(t) {
  const el = $('toast'); el.textContent = t; el.classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove('show'), 2600);
}
function showPin(msg) { $('pinModal').classList.add('show'); $('pinErr').textContent = msg || ''; $('pinInput').value = ''; setTimeout(() => $('pinInput').focus(), 50); }
function submitPin() {
  const v = $('pinInput').value.trim(); if (!v) return;
  pin = v; try { sessionStorage.setItem('sa_pin', pin); } catch (e) {}
  $('pinModal').classList.remove('show'); known = null; refresh();
}
async function call(path) {
  const ctl = new AbortController(), t = setTimeout(() => ctl.abort(), 3500);
  try {
    const r = await fetch(path + (path.indexOf('?') < 0 ? '?' : '&') + 'pin=' + encodeURIComponent(pin), { signal: ctl.signal, cache: 'no-store' });
    if (r.status === 401) {
      pin = ''; try { sessionStorage.removeItem('sa_pin'); } catch (e) {}
      showPin('Wrong PIN, try again'); throw new Error('auth');
    }
    return r;
  } finally { clearTimeout(t); }
}
function fmt(sec) {
  sec = Math.max(0, sec | 0);
  const h = (sec / 3600) | 0, m = ((sec % 3600) / 60) | 0, s = sec % 60, p = n => String(n).padStart(2, '0');
  return h ? h + ':' + p(m) + ':' + p(s) : p(m) + ':' + p(s);
}
function setPill(cls, txt) { $('pill').className = 'pill ' + cls; $('pillTxt').textContent = txt; }

function render() {
  setPill(data.active ? 'on' : 'closed', data.active ? 'SESSION OPEN' : 'SESSION CLOSED');
  $('count').textContent = data.count;
  $('timer').textContent = fmt(data.sec);
  $('stateTxt').textContent = data.active ? 'Attendance is open' : 'Closed';
  $('ip').textContent = 'http://' + data.ip;
  $('ssid').textContent = 'Wi-Fi: ' + data.ssid;

  const cs = parseInt($('classSize').value, 10) || 0;
  if (cs > 0) {
    const p = Math.min(100, Math.round(data.count * 100 / cs));
    $('ring').style.setProperty('--deg', (p * 3.6) + 'deg');
    $('ringTxt').textContent = p + '%';
    $('pct').textContent = data.count + ' of ' + cs + ' students';
  } else {
    $('ring').style.setProperty('--deg', '0deg');
    $('ringTxt').textContent = data.count;
    $('pct').textContent = 'Set class strength for %';
  }

  const fresh = new Set(), isFirst = known === null;
  if (isFirst) known = new Set();
  data.students.forEach(s => {
    if (!known.has(s.regno)) { known.add(s.regno); if (!isFirst) { fresh.add(s.regno); toast(s.name + ' marked present'); } }
  });

  const q = $('search').value.trim().toLowerCase();
  const list = data.students.map((s, i) => ({ s: s, n: i + 1 }))
    .filter(o => !q || o.s.name.toLowerCase().indexOf(q) >= 0 || o.s.regno.toLowerCase().indexOf(q) >= 0)
    .reverse();
  $('rows').innerHTML = list.length ? list.map(o =>
    '<tr class="' + (fresh.has(o.s.regno) ? 'new' : '') + '"><td>' + o.n + '</td>' +
    '<td><div class="who"><div class="av">' + esc((o.s.name.trim()[0] || '?').toUpperCase()) + '</div>' + esc(o.s.name) + '</div></td>' +
    '<td>' + esc(o.s.regno) + '</td><td class="mono">' + fmt(o.s.t) + '</td><td class="mono">' + esc(o.s.ip) + '</td></tr>'
  ).join('') : '<tr><td colspan="5" class="empty">' + (data.students.length ? 'No matching students' : 'No attendance yet') + '</td></tr>';
}

async function refresh() {
  if (!pin) return;
  try { const r = await call('/data'); data = await r.json(); render(); }
  catch (e) { if (e.message !== 'auth') setPill('off', 'OFFLINE'); }
}
async function tick() { await refresh(); setTimeout(tick, 2500); }

async function act(path, okMsg) {
  try { await call(path); toast(okMsg); refresh(); } catch (e) { if (e.message !== 'auth') toast('Device not reachable'); }
}
function downloadCsv() {
  if (window.__PREVIEW__) {
    const rows = [['Name','Register Number','Device IP','Time (mm:ss)']].concat(data.students.map(s => [s.name, s.regno, s.ip, fmt(s.t)]));
    const blob = new Blob([rows.map(r => r.map(c => '"' + String(c).replace(/"/g, '""') + '"').join(',')).join('\n')], { type: 'text/csv' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'attendance.csv'; a.click(); return;
  }
  window.location.href = '/csv?pin=' + encodeURIComponent(pin);
}

$('pinBtn').addEventListener('click', submitPin);
$('pinInput').addEventListener('keydown', e => { if (e.key === 'Enter') submitPin(); });
$('bStart').addEventListener('click', () => act('/toggle?state=start', 'Attendance started'));
$('bStop').addEventListener('click', () => act('/toggle?state=stop', 'Attendance stopped'));
$('bCsv').addEventListener('click', downloadCsv);
$('bClear').addEventListener('click', () => { if (confirm('Clear the whole attendance list? Download the CSV first.')) act('/clear', 'List cleared'); });
$('search').addEventListener('input', render);
try { $('classSize').value = localStorage.getItem('sa_class') || ''; } catch (e) {}
$('classSize').addEventListener('input', () => { try { localStorage.setItem('sa_class', $('classSize').value); } catch (e) {} render(); });

if (!pin) showPin('');
tick();
</script>
</body>
</html>
)HTMLPAGE";

// ---------------- DATA ----------------
struct Student {
  String name;
  String regno;
  String ip;
  String did;      // browser-generated device id
  uint32_t sec;    // seconds after session start
};

Student students[MAX_STUDENTS];
int studentCount = 0;
bool attendanceActive = false;
uint32_t sessionStart = 0;   // 0 = not started yet
uint32_t sessionElapsed = 0;  // frozen elapsed time after STOP
uint32_t sessionId = 0;

// ---------------- JOYSTICK / MENU ----------------
const int MENU_COUNT = 3;
const char* menuItems[MENU_COUNT] = { "Start attendance", "Stop attendance", "View status" };
int menuIndex = 0;
bool showingStatus = false;
unsigned long statusShownAt = 0, lastMove = 0, lastPress = 0;

// =====================================================
// HELPERS
// =====================================================
// =====================================================
// BUZZER / FEEDBACK
// Active buzzer: HIGH = ON, LOW = OFF
// =====================================================
void buzzerOn() {
  digitalWrite(BUZZER, HIGH);
}

void buzzerOff() {
  digitalWrite(BUZZER, LOW);
}

void beep(uint16_t ms) {
  buzzerOn();
  delay(ms);
  buzzerOff();
}

void startBeep() {
  beep(200);
}

void stopBeep() {
  beep(200);
  delay(120);
  beep(200);
}

void successBeep() {
  beep(120);
}

void errorBeep() {
  beep(100);
  delay(100);
  beep(100);
}

void updateLeds() {
  digitalWrite(GREEN_LED, attendanceActive ? HIGH : LOW);
  digitalWrite(RED_LED, attendanceActive ? LOW : HIGH);
}

void successFeedback() {
  digitalWrite(GREEN_LED, LOW);
  successBeep();
  digitalWrite(GREEN_LED, HIGH);
  delay(80);
  updateLeds();
}

void errorFeedback() {
  digitalWrite(RED_LED, HIGH);
  errorBeep();
  digitalWrite(RED_LED, LOW);
  updateLeds();
}

String cleanText(String s, size_t maxLen) {
  s.trim();
  String out;
  for (size_t i = 0; i < s.length() && out.length() < maxLen; i++) {
    char c = s[i];
    if ((uint8_t)c >= 32 && c != 127) out += c;
  }
  out.trim();
  return out;
}

String jsonEscape(const String& s) {
  String o;
  for (size_t i = 0; i < s.length(); i++) {
    char c = s[i];
    if (c == '"' || c == '\\') { o += '\\'; o += c; }
    else if ((uint8_t)c < 32) o += ' ';
    else o += c;
  }
  return o;
}

String csvField(String s) {
  if (s.length() && (s[0] == '=' || s[0] == '+' || s[0] == '-' || s[0] == '@')) s = "'" + s;
  s.replace("\"", "\"\"");
  return "\"" + s + "\"";
}

String mmss(uint32_t sec) {
  char buf[12];
  snprintf(buf, sizeof(buf), "%02u:%02u", (unsigned)(sec / 60), (unsigned)(sec % 60));
  return String(buf);
}

// =====================================================
// OLED SCREENS
// =====================================================
void drawMenu() {
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(OLED_ON);
  display.setCursor(22, 0);
  display.print("SMARTATTEND");
  display.drawLine(0, 10, 127, 10, OLED_ON);
  for (int i = 0; i < MENU_COUNT; i++) {
    display.setCursor(6, 16 + i * 11);
    display.print(i == menuIndex ? "> " : "  ");
    display.print(menuItems[i]);
  }
  display.drawLine(0, 52, 127, 52, OLED_ON);
  display.setCursor(0, 55);
  display.print(attendanceActive ? "OPEN" : "CLOSED");
  display.setCursor(64, 55);
  display.print("Present:");
  display.print(studentCount);
  display.display();
}

void drawStatus() {
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(OLED_ON);
  display.setCursor(28, 0);
  display.print("VIEW STATUS");
  display.drawLine(0, 10, 127, 10, OLED_ON);
  display.setCursor(0, 14);  display.print("Present : "); display.print(studentCount);
  display.setCursor(0, 25);  display.print("Session : "); display.print(attendanceActive ? "OPEN" : "CLOSED");
  display.setCursor(0, 36);  display.print("WiFi    : "); display.print(WIFI_SSID);
  display.setCursor(0, 47);  display.print("IP      : "); display.print(WiFi.softAPIP());
  display.display();
}

void refreshScreen() {
  if (showingStatus) drawStatus(); else drawMenu();
}

void flashMessage(const char* l1, const char* l2) {
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(OLED_ON);
  display.setCursor(32, 22); display.print(l1);
  display.setCursor(32, 36); display.print(l2);
  display.display();
  delay(600);
}

// =====================================================
// SESSION CONTROL (used by joystick and dashboard)
// =====================================================
void startSession() {
  attendanceActive = true;
  sessionStart = millis();
  sessionElapsed = 0;
  sessionId = esp_random();

  startBeep();
  updateLeds();
}

void stopSession() {
  if (attendanceActive && sessionStart != 0) {
    sessionElapsed = (millis() - sessionStart) / 1000;
  }

  attendanceActive = false;
  sessionStart = 0;

  stopBeep();
  updateLeds();
}

void clearSession() {
  for (int i = 0; i < MAX_STUDENTS; i++) {
    students[i].name = ""; students[i].regno = ""; students[i].ip = ""; students[i].did = ""; students[i].sec = 0;
  }
  studentCount = 0;
  sessionStart = attendanceActive ? millis() : 0;
  sessionElapsed = 0;
  sessionId = esp_random();
}

// =====================================================
// JOYSTICK
// =====================================================
void handleJoystick() {
  unsigned long now = millis();
  int y = analogRead(JOY_Y);
#if JOY_INVERT_Y
  y = 4095 - y;
#endif
  bool pressed = (digitalRead(JOY_SW) == LOW);

  if (showingStatus) {
    if ((pressed && now - statusShownAt > 500) || now - statusShownAt > 6000) {
      showingStatus = false;
      lastPress = now;
      drawMenu();
    }
    return;
  }

  if (now - lastMove > 250) {
    // UP = previous item, DOWN = next item.
    if (y < 1000) {
      menuIndex = (menuIndex + MENU_COUNT - 1) % MENU_COUNT;
      lastMove = now;
      drawMenu();
    }
    else if (y > 3000) {
      menuIndex = (menuIndex + 1) % MENU_COUNT;
      lastMove = now;
      drawMenu();
    }
  }

  if (pressed && now - lastPress > 400) {
    lastPress = now;
    if (menuIndex == 0) { startSession(); flashMessage("Attendance", "STARTED"); drawMenu(); }
    else if (menuIndex == 1) { stopSession(); flashMessage("Attendance", "STOPPED"); drawMenu(); }
    else { showingStatus = true; statusShownAt = now; drawStatus(); }
  }
}

// =====================================================
// WEB HANDLERS
// =====================================================
bool authorized() {
  if (server.arg("pin") == ADMIN_PIN) return true;
  server.send(401, "text/plain", "Unauthorized");
  return false;
}

void noCache() {
  server.sendHeader("Cache-Control", "no-store");
}

void handleRoot()  { server.send_P(200, "text/html", STUDENT_HTML); }
void handleAdmin() { server.send_P(200, "text/html", ADMIN_HTML); }

void handleStatus() {
  noCache();
  String j = "{\"active\":";
  j += attendanceActive ? "true" : "false";
  j += ",\"sid\":" + String(sessionId) + "}";
  server.send(200, "application/json", j);
}

void reply(const char* kind, const String& msg) {
  noCache();
  server.send(200, "text/plain", String(kind) + "|" + msg);
}

void handleSubmit() {
  if (server.method() != HTTP_POST) { server.send(405, "text/plain", "Method not allowed"); return; }

  if (!attendanceActive) { reply("ERR", "Attendance is closed right now"); errorFeedback(); return; }

  String name  = cleanText(server.arg("name"), 40);
  String regno = cleanText(server.arg("regno"), 20);
  String did   = cleanText(server.arg("did"), 40);
  regno.toUpperCase();

  if (name.length() < 2 || regno.length() < 2) { reply("ERR", "Enter your name and register number"); errorFeedback(); return; }

  String ip = server.client().remoteIP().toString();
  for (int i = 0; i < studentCount; i++) {
    if (students[i].ip == ip || students[i].regno == regno || (did.length() > 0 && students[i].did == did)) {
      reply("ERR", "Already marked from this device or register number");
      errorFeedback();
      return;
    }
  }

  if (studentCount >= MAX_STUDENTS) { reply("ERR", "Attendance list is full"); errorFeedback(); return; }

  Student& s = students[studentCount];
  s.name = name; s.regno = regno; s.ip = ip; s.did = did;
  s.sec = (millis() - sessionStart) / 1000;
  studentCount++;

  reply("OK", "Attendance marked");
  successFeedback();
  refreshScreen();
}

void handleData() {
  if (!authorized()) return;
  noCache();
  uint32_t sec = attendanceActive && sessionStart ? (millis() - sessionStart) / 1000 : sessionElapsed;
  String j;
  j.reserve(200 + studentCount * 110);
  j = "{\"active\":";
  j += attendanceActive ? "true" : "false";
  j += ",\"count\":" + String(studentCount);
  j += ",\"sec\":" + String(sec);
  j += ",\"ip\":\"" + WiFi.softAPIP().toString() + "\"";
  j += ",\"ssid\":\"" + jsonEscape(String(WIFI_SSID)) + "\"";
  j += ",\"students\":[";
  for (int i = 0; i < studentCount; i++) {
    if (i) j += ",";
    j += "{\"name\":\"" + jsonEscape(students[i].name) + "\"";
    j += ",\"regno\":\"" + jsonEscape(students[i].regno) + "\"";
    j += ",\"ip\":\"" + jsonEscape(students[i].ip) + "\"";
    j += ",\"t\":" + String(students[i].sec) + "}";
  }
  j += "]}";
  server.send(200, "application/json", j);
}

void handleToggle() {
  if (!authorized()) return;
  String state = server.arg("state");
  if (state == "start") startSession();
  else if (state == "stop") stopSession();
  else { server.send(400, "text/plain", "Bad state"); return; }
  refreshScreen();
  server.send(200, "text/plain", "OK");
}

void handleClear() {
  if (!authorized()) return;
  clearSession();
  refreshScreen();
  server.send(200, "text/plain", "OK");
}

void handleCsv() {
  if (!authorized()) return;
  String csv = "\xEF\xBB\xBF";   // UTF-8 BOM so Excel shows names correctly
  csv += "No,Name,Register Number,Device IP,Time After Start (mm:ss)\r\n";
  for (int i = 0; i < studentCount; i++) {
    csv += String(i + 1) + "," + csvField(students[i].name) + "," + csvField(students[i].regno) + "," +
           csvField(students[i].ip) + "," + mmss(students[i].sec) + "\r\n";
  }
  server.sendHeader("Content-Disposition", "attachment; filename=attendance.csv");
  server.send(200, "text/csv", csv);
}

// Any unknown URL (phone connectivity checks etc.) goes to the attendance page,
// which makes the page open automatically like a hotspot login screen.
void handleNotFound() {
  server.sendHeader("Location", String("http://") + AP_IP.toString() + "/", true);
  server.send(302, "text/plain", "");
}

// =====================================================
// SETUP / LOOP
// =====================================================
void setup() {
  Serial.begin(115200);

  pinMode(GREEN_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  pinMode(BUZZER, OUTPUT);
  pinMode(JOY_SW, INPUT_PULLUP);
  buzzerOff();
  updateLeds();

  Wire.begin(OLED_SDA, OLED_SCL);
#if USE_SH1106
  bool oledOk = display.begin(0x3C, true);
#else
  bool oledOk = display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
#endif
  if (!oledOk) Serial.println("OLED not found - check wiring / USE_SH1106 / address");
  display.clearDisplay();
  display.setTextColor(OLED_ON);
  display.setTextSize(1);
  display.setCursor(18, 28);
  display.print("Starting WiFi...");
  display.display();

  WiFi.mode(WIFI_AP);
  WiFi.softAPConfig(AP_IP, AP_IP, IPAddress(255, 255, 255, 0));
  WiFi.softAP(WIFI_SSID, WIFI_PASS, 1, 0, 10);   // channel 1, visible, up to 10 clients
  dnsServer.start(53, "*", AP_IP);
  sessionId = esp_random();

  server.on("/", handleRoot);
  server.on("/admin", handleAdmin);
  server.on("/status", handleStatus);
  server.on("/submit", handleSubmit);
  server.on("/data", handleData);
  server.on("/toggle", handleToggle);
  server.on("/clear", handleClear);
  server.on("/csv", handleCsv);
  server.onNotFound(handleNotFound);
  server.begin();

  Serial.print("AP ready. Open http://");
  Serial.println(WiFi.softAPIP());
  drawMenu();
}

void loop() {
  dnsServer.processNextRequest();
  server.handleClient();
  handleJoystick();
  delay(1);
}
